
for n in range (1,51):
    print('{} '.format(n))